package com.samirdev.spring_chat_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringChatAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
