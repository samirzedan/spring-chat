package com.samirdev.spring_chat_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringChatAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringChatAppApplication.class, args);
	}

}
